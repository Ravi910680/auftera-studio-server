<div class="sd-con-ico dsc-inln-flx" style="
">
    
    <div class="sd-hd-con"><img src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" width="" style="
    padding: 2vh
    ">
</div>

<div class="icon-con-of-sd">

    <style>


#main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}



</style>
<div class="icon-main-con">
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="campign/" data-target-link="https://campign.auftera.com/campigns/all-campign" data-toggle="tooltip" data-placement="right" title="Sheduled Campigns"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278281/automation/schedule_send_black_24dp_wybxtb.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/#acl" data-toggle="tooltip" data-placement="right" title="Manage Contact List"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1628748461/email-crm/playlist_add_circle_black_24dp_eryixo.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="template/" data-target-link="https://template.auftera.com/template/" data-toggle="tooltip" data-placement="right" title="Manage Template"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278301/automation/web_black_24dp_kx5cze.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="studio/" data-target-link="https://studio.auftera.com/studio/" data-toggle="tooltip" data-placement="right" title="Browse Studio"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278284/automation/camera_black_24dp_ldwdgu.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="automation/" data-target-link="https://automation.auftera.com/automation/" data-toggle="tooltip" data-placement="right" title="Launch Automation"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1627707060/automation/model_training_black_24dp_wjuu9i.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="social/" data-target-link="https://social.auftera.com/social/" data-toggle="tooltip" data-placement="right" title="Social Post"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1627537307/automation/share_black_24dp_wpgnni.svg"></div>
</div>
<script>


id='<?php echo $id;?>';
email='<?php echo $email;?>';

$(document).on('click','.com-for-lnk',function(){



$("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');

url_lnk=$(this).attr('data-target-link');
ses_path=$(this).attr('data-path-ses');


var sourceString = url_lnk.replace('http://','').replace('https://','').replace('www.','').split(/[/?#]/)[0];

if($(this).attr('data-for-serv')=='1'){

red_url="https://"+sourceString+"/"+ses_path+"confige/crt_ses.php?id="+id+"&email="+email+"&url_red="+url_lnk;

console.log(red_url);


}else if($(this).attr('data-for-serv')=='0'){



red_url=$(this).attr('data-target-link');





}

console.log(red_url);
window.location.href=red_url;


})
</script>


</div>
        
    
    </div>