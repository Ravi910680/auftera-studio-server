<?php
  
session_start();




session_destroy();

$req_page=$_GET['next_act_serv'];


$url="https://auftera.com/confige/logout/";

header("Location: ".$url);

?>
