<?php


require("../confige/imagesave.conf.php");

$img_name= $_POST['img_name'];

$explode_data=explode("^",$img_name);

$str_name_tbl=$explode_data[0]."^".$explode_data[1];




$get_data_query = "SELECT *  FROM `".$str_name_tbl."` WHERE image='".$img_name."'";

$res_data=$imagesave->query($get_data_query);

if ($res_data->num_rows > 0) {
 
    while($row = $res_data->fetch_assoc()) {
        echo json_encode($row);
    }
} else {
    echo "0 results";
}


?>
