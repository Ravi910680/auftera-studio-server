<?php
session_start();



require("../confige/imagedir.conf.php");

require("../confige/imagesave.conf.php");




$id=$_SESSION["id"];
$dir_name= $_POST["add_dir_name"];
if(isset($dir_name)){
     $date= date("Y-m-d");
$undefineencode=$id."^".base64_encode($dir_name);
$insertdatasql = "INSERT INTO `imagedirname`  VALUES ('$undefineencode','$id','$date','0','0','0'); ";
if($imagedir->query($insertdatasql)===TRUE){
$imagetbl = "CREATE TABLE `".$undefineencode."`(

      image VARCHAR(50) PRIMARY KEY NOT NULL,
        width VARCHAR(30),
        height VARCHAR(30),
        size VARCHAR(255),
	org_name VARCHAR(255),
date_img DATETIME
    )";
if($imagesave->query($imagetbl)===TRUE){
    echo "0";

}



}else{

    echo "1";
}


}



?>
