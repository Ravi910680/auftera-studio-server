<?php  
      // requires php5  \
      
      define('UPLOAD_DIR', 'images/');  
      $img = $_GET['imgBase64'];  
      
      $img = str_replace('data:image/png;base64,', '', $img);  
      $img = str_replace(' ', '+', $img);  
      $data = base64_decode($img);  
      $file = UPLOAD_DIR .$_GET['imgname'];  
      $success = file_put_contents($file, $data);  
      echo $success;
 ?>  